function R_VID
global frames frate 
[name11,Path11] = uigetfile('..\Video\*','Select video file');
ss1=VideoReader([Path11 name11]);
numFrames = ss1.NumberOfFrames;
lenvid=ss1.Duration;
frate=ss1.FrameRate;
prompt = {'range 0s',['to ' num2str(lenvid) 's']};
title = ['This video is ' num2str(frate) 'fps. Enter a length of the video ...'];
definput = {'0' ,num2str(lenvid)};
x = inputdlg(prompt,title,[1 70 ; 1 70 ],definput);
y1=round(str2double(x{1})*frate)+1;
y2=round(str2double(x{2})*frate);
frames=[];
cnt1=0;
for k=y1:y2
    cnt1=cnt1+1;
    orginal11=read(ss1,k);
    frames(:,:,cnt1)=rgb2gray(orginal11);
    %     imwrite(c1,['..\Video\a' int2str(10000+cnt1) '.jpg']);
end
end
