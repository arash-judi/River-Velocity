function out=MA(in)
len=length(in);
out=in;
for l=2:len-1
    out(l)=mean(in(l-1:l+1));
end
end