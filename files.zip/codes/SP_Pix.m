function [outx1, outx2, outy1, outy2]=SP_Pix(in,num1)

for l=1:num1
    
    fa1=in(:,1,1,l);
    fa2=in(:,2,1,l);
    fa3=in(:,3,1,l);
    fb1=in(:,1,2,l);
    fb2=in(:,2,2,l);
    fb3=in(:,3,2,l);
    fc1=in(:,1,3,l);
    fc2=in(:,2,3,l);
    fc3=in(:,3,3,l);
    fd1=in(:,1,4,l);
    fd2=in(:,2,4,l);
    fd3=in(:,3,4,l);
    
    delx1(l)=abs(fa2(1)-fa1(1));
    delx2(l)=abs(fb2(1)-fb1(1));
    delx3(l)=abs(fc2(1)-fc1(1));
    delx4(l)=abs(fd2(1)-fd1(1));
    Sx1(1,l)=delx1(l)+delx2(l)+delx3(l)+delx4(l);
    
    
    dely1(l)=abs(fa2(2)-fa1(2));
    dely2(l)=abs(fb2(2)-fb1(2));
    dely3(l)=abs(fc2(2)-fc1(2));
    dely4(l)=abs(fd2(2)-fd1(2));
    Sy1(1,l)=dely1(l)+dely2(l)+dely3(l)+dely4(l);
    
    
    Delx1(l)=abs(fa3(1)-fa1(1));
    Delx2(l)=abs(fb3(1)-fa1(1));
    Delx3(l)=abs(fc3(1)-fa1(1));
    Delx4(l)=abs(fd3(1)-fa1(1));
    Sx2(1,l)=Delx1(l)+Delx2(l)/2+Delx3(l)/3+Delx4(l)/4;
    
    
    Dely1(l)=abs(fa3(2)-fa1(2));
    Dely2(l)=abs(fb3(2)-fa1(2));
    Dely3(l)=abs(fc3(2)-fa1(2));
    Dely4(l)=abs(fd3(2)-fa1(2));
    Sy2(1,l)=Dely1(l)+Dely2(l)/2+Dely3(l)/3+Dely4(l)/4;
    
    
end
outx1=Sx1;
outx2=Sx2;
outy1=Sy1;
outy2=Sy2;

end