function out=distan(p1,p2)
out=sqrt(sum((p1-p2).^2));
end