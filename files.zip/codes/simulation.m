function res=simulation(a,b)
siz=size(a);
siz1=size(b);
for l=1:siz(2)-siz1(2)+1
    for k=1:siz(1)-siz1(1)+1
        res(k,l)=sum(sum(abs(a(k:siz1(1)+k-1,l:siz1(2)+l-1)-b)));
    end
end
