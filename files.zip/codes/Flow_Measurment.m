function [A, Rh, average]=Flow_Measurment(speed1,profile1)

profile1=abs(profile1);
profile(:,1)=profile1(1,1):.1:profile1(end,1);
profile(:,2)=interp1(profile1(:,1),profile1(:,2),profile(:,1));
speed=interp1(profile1(:,1),speed1,profile(:,1));
ZE1=find(speed(1:end/2)<.01);
ZE2=find(speed(end/2:end)<.01);
z1=max(ZE1);
z2=max(ZE2)-min(ZE2);
H=0;
flag=0;
P1=profile;
if z1>1
    flag=1;
    profile(1:z1-1,:)=[];
    speed(1:z1-1)=[];
end
if z2<length(speed)
    flag=1;
    profile(end-z2:end,:)=[];
    speed(end-z2:end)=[];
end
P2=profile;
if flag==1
    if profile(1,2)>=profile(end,2)
        H=profile(end,2);
        profile=profile-profile(end,2);
    else
        H=profile(1,2);
        profile=profile-profile(1,2);
    end
    
end
figure,plot(P1(:,1),-1.*P1(:,2),'linewidth',2)
hold on
plot([P2(1,1),P2(end,1)],-1.*[min([P2(1,2),P2(end,2)]),min([P2(1,2),P2(end,2)])],'linewidth',2)
ylabel('Deep')
xlabel('Width')

A=trapz(profile(:,1),profile(:,2));
p = 0;
for l=1:length(profile)-1
    p=p+distan(profile(l,:),profile(l+1,:));
end

n=.02;
Rh=A/p;
d50 = (21.1*n)^6;
Ks=3.72068*4*Rh*exp((-0.103252*(4*Rh)^0.166667)/n);

if n>=((Rh/10)^(1/6))/21.1
    q = 2.03293*log(Rh/d50)+1.14905;
else
    q = 2*log(Rh/Ks)+2.2;
end

for l=1:length(profile)
    
    if profile(l,2)==0
        U(l,1)=speed(l);
        mu(l)=speed(l);
    else
        Z=profile(l,2):-0.01:0;
        u=speed(l).*(Z./profile(l,2)).^(1/q);
        mu(l)=mean(u);
        U(l,1:length(Z))=u;
    end
    
end

figure,imagesc(U')
colorbar
title('Deep velocity')
ylabel('Deep')
average=mean(mean(U));
end