function [SPREX, SPREY, SPREXY, len_line]=SPRE(PXY,dist,pix,SPX,SPY,SPXY,frate,lin,BB)

D(1,1)=sqrt((PXY(1,1)-PXY(1,2))^2+(PXY(2,1)-PXY(2,2))^2);
D(2,1)=sqrt((PXY(1,2)-PXY(1,3))^2+(PXY(2,2)-PXY(2,3))^2);
D(3,1)=sqrt((PXY(1,3)-PXY(1,4))^2+(PXY(2,3)-PXY(2,4))^2);
D(4,1)=sqrt((PXY(1,1)-PXY(1,4))^2+(PXY(2,1)-PXY(2,4))^2);
D(5,1)=sqrt((PXY(1,1)-PXY(1,3))^2+(PXY(2,1)-PXY(2,3))^2);
D(6,1)=sqrt((PXY(1,2)-PXY(1,4))^2+(PXY(2,2)-PXY(2,4))^2);
D(:,2)=dist';
D(:,3)=D(:,2)./D(:,1);
s(1,1)=D(1,3)+D(5,3)-D(2,3);
s(2,1)=D(2,3)+D(6,3)-D(3,3);
s(3,1)=D(3,3)+D(5,3)-D(4,3);
s(4,1)=D(4,3)+D(6,3)-D(1,3);
for l=1:length(pix)
    D1=sqrt((pix(1,l)-PXY(1,1))^2+(pix(2,l)-PXY(2,1))^2);
    D2=sqrt((pix(1,l)-PXY(1,2))^2+(pix(2,l)-PXY(2,2))^2);
    D3=sqrt((pix(1,l)-PXY(1,3))^2+(pix(2,l)-PXY(2,3))^2);
    D4=sqrt((pix(1,l)-PXY(1,4))^2+(pix(2,l)-PXY(2,4))^2);
    alpha=1/(1+D1*(1/D2+1/D3+1/D4));
    beta=1/(1+D2*(1/D1+1/D3+1/D4));
    teta=1/(1+D3*(1/D2+1/D1+1/D4));
    gama=1/(1+D4*(1/D2+1/D3+1/D1));
    S(l)=s(1)*alpha+s(2)*beta+s(3)*teta+s(4)*gama;
end
for l=1:length(lin)
    D1=sqrt((lin(1,l)-PXY(1,1))^2+(lin(2,l)-PXY(2,1))^2);
    D2=sqrt((lin(1,l)-PXY(1,2))^2+(lin(2,l)-PXY(2,2))^2);
    D3=sqrt((lin(1,l)-PXY(1,3))^2+(lin(2,l)-PXY(2,3))^2);
    D4=sqrt((lin(1,l)-PXY(1,4))^2+(lin(2,l)-PXY(2,4))^2);
    alpha=1/(1+D1*(1/D2+1/D3+1/D4));
    beta=1/(1+D2*(1/D1+1/D3+1/D4));
    teta=1/(1+D3*(1/D2+1/D1+1/D4));
    gama=1/(1+D4*(1/D2+1/D3+1/D1));
    L(l)=s(1)*alpha+s(2)*beta+s(3)*teta+s(4)*gama;
end
for l=1:length(BB)
    D1=sqrt((BB(1,l)-PXY(1,1))^2+(BB(2,l)-PXY(2,1))^2);
    D2=sqrt((BB(1,l)-PXY(1,2))^2+(BB(2,l)-PXY(2,2))^2);
    D3=sqrt((BB(1,l)-PXY(1,3))^2+(BB(2,l)-PXY(2,3))^2);
    D4=sqrt((BB(1,l)-PXY(1,4))^2+(BB(2,l)-PXY(2,4))^2);
    alpha=1/(1+D1*(1/D2+1/D3+1/D4));
    beta=1/(1+D2*(1/D1+1/D3+1/D4));
    teta=1/(1+D3*(1/D2+1/D1+1/D4));
    gama=1/(1+D4*(1/D2+1/D3+1/D1));
    LL(l)=s(1)*alpha+s(2)*beta+s(3)*teta+s(4)*gama;
end
SPREX=(SPX.*S).*frate/4;
SPREY=(SPY.*S).*frate/4;
SPREXY=(SPXY.*S).*frate/4;
len_line(1)=sum(L);
len_line(2)=sum(LL)*sqrt((BB(1,1)-BB(1,2))^2+(BB(2,1)-BB(2,2))^2)/2;
end