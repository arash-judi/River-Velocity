function R_Excel
global  num profile1
[name11,Path11] = uigetfile('*.xls','Select exel file');
profile1 = xlsread([Path11 name11]);
siz=size(profile1);
num=siz(1);
end