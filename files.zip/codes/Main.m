function [A, Rh, Q, ave_speed]=Main
%% read video file and get frames
global frames frate num profile1
frames=frames./255;
siz=size(frames);
CNT=fix((siz(3)-1)/4);
%% ********************** get points **************************
in=frames(:,:,1:3);

imshow(in)
[x(1),y(1)] = ginput(1);
x=round(x);
y=round(y);
in(y(1)-7:y(1)+7,x(1)-7:x(1)+7,1)=1;
in(y(1)-7:y(1)+7,x(1)-7:x(1)+7,2)=0;
in(y(1)-7:y(1)+7,x(1)-7:x(1)+7,3)=0;
imshow(in)
[x(2),y(2)] = ginput(1);
x=round(x);
y=round(y);
in(y(2)-7:y(2)+7,x(2)-7:x(2)+7,1)=0;
in(y(2)-7:y(2)+7,x(2)-7:x(2)+7,2)=1;
in(y(2)-7:y(2)+7,x(2)-7:x(2)+7,3)=0;
imshow(in)
[x(3),y(3)] = ginput(1);
x=round(x);
y=round(y);
in(y(3)-7:y(3)+7,x(3)-7:x(3)+7,1)=0;
in(y(3)-7:y(3)+7,x(3)-7:x(3)+7,2)=0;
in(y(3)-7:y(3)+7,x(3)-7:x(3)+7,3)=1;
imshow(in)
[x(4),y(4)] = ginput(1);
x=round(x);
y=round(y);
in(y(4)-7:y(4)+7,x(4)-7:x(4)+7,1)=1;
in(y(4)-7:y(4)+7,x(4)-7:x(4)+7,2)=0;
in(y(4)-7:y(4)+7,x(4)-7:x(4)+7,3)=1;
imshow(in)
PXY=[y;x];
%% ********************** get dist **************************
prompt = {'dist_Red-Green(m)','dist_Green-Blue(m)','dist_Blue-Pink(m)','dist_Pink-Red(m)','dist_Red-Blue(m)','dist_Pink-Green(m)'};
tit = 'Insert Dists';
definput = {'0' ,'0','0','0','0','0'};
dists = inputdlg(prompt,tit,[1 20 ; 1 20 ; 1 20; 1 20; 1 20; 1 20],definput);
dist=[str2double(dists{1}),str2double(dists{2}),str2double(dists{3}),str2double(dists{4}),str2double(dists{5}),str2double(dists{6})];

%% ********************** get line **************************
imshow(in)
B=getline;
close
D=sqrt((B(1,1)-B(2,1))^2+(B(1,2)-B(2,2))^2);
num1=D/20;
if num1<num
    num1=num;
end
gam1=(B(1,2)-B(2,2))/num1;
gam2=(B(1,1)-B(2,1))/num1;

for k=1:num1
    points(1,k)=round(B(1,2)-k*gam1+gam1/2);
    points(2,k)=round(B(1,1)-k*gam2+gam2/2);
end

dist1=abs(points(1,1)-(points(1,1)+points(1,2))/2);
dist2=abs(points(2,1)-(points(2,1)+points(2,2))/2);
distm=max(dist1,dist2);
%%
for L=1:CNT
    for cnt=1:num1
        template1=frames(points(1,cnt)-ceil(sqrt(distm)):points(1,cnt)+ceil(sqrt(distm)),points(2,cnt)-ceil(sqrt(distm)):points(2,cnt)+ceil(sqrt(distm)),1+(L-1)*4);
        for l=1:4
            template=frames(points(1,cnt)-ceil(sqrt(distm)):points(1,cnt)+ceil(sqrt(distm)),points(2,cnt)-ceil(sqrt(distm)):points(2,cnt)+ceil(sqrt(distm)),l+(L-1)*4);
            im=frames(points(1,cnt)-distm:points(1,cnt)+distm,points(2,cnt)-distm:points(2,cnt)+distm,l+(L-1)*4);
            im1=frames(points(1,cnt)-distm:points(1,cnt)+distm,points(2,cnt)-distm:points(2,cnt)+distm,l+1+(L-1)*4);
            %         imshow(im)
            C=simulation(im,template);
            C1=simulation(im1,template);
            C2=simulation(im1,template1);
            [nn, n1]=min(C);
            [mm, n2]=min(min(C));
            res(:,1,l,cnt)=[n1(n2); n2];
            [nn, n1]=min(C1);
            [mm, n2]=min(min(C1));
            res(:,2,l,cnt)=[n1(n2); n2];
            [nn, n1]=min(C2);
            [mm, n2]=min(min(C2));
            res(:,3,l,cnt)=[n1(n2); n2];
        end
    end
    [a, b, c, d]=SP_Pix(res,num1);
    SPPX1(L,:)=a;
    SPPX2(L,:)=b;
    SPPY1(L,:)=c;
    SPPY2(L,:)=d;
end

%%
SPX0=mean([SPPX1;SPPX2]);
SPY0=mean([SPPY1;SPPY2]);

if num==length(SPX0)
    S1=SPX0;
    S2=SPY0;
elseif num<length(SPX0)
    f=length(SPX0)/num;
    for l=1:num
        S1(l)=mean(SPX0((l-1)*f+1:l*f));
        S2(l)=mean(SPY0((l-1)*f+1:l*f));
    end
elseif num>length(SPX0)
end
%%
S3=abs(S1+1j*S2);
SPX=MA(S1);
SPY=MA(S2);
SPXY=MA(S3);

gam1=(B(1,2)-B(2,2))/num;
gam2=(B(1,1)-B(2,1))/num;

for k=1:num
    pix(1,k)=round(B(1,2)-k*gam1+gam1/2);
    pix(2,k)=round(B(1,1)-k*gam2+gam2/2);
end


gam1=(B(1,2)-B(2,2))/D;
gam2=(B(1,1)-B(2,1))/D;

for k=1:fix(D)
    lin(1,k)=round(B(1,2)-k*gam1+gam1/2);
    lin(2,k)=round(B(1,1)-k*gam2+gam2/2);
end
%%
BB=[B(:,2),B(:,1)]';
[SPREX, SPREY, SPREXY, len_line]=SPRE(PXY,dist,pix,SPX,SPY,SPXY,frate,lin,BB);
%%
figure
subplot(3,1,1)
plot(SPREX, 'linewidth',2)
grid
title('Surface velocity in x direction');
ylabel('velocity(m/s)')

subplot(3,1,2)
plot(SPREY, 'linewidth',2)
grid
title('Surface velocity in y direction')
ylabel('velocity(m/s)')

subplot(3,1,3)
plot(SPREXY, 'linewidth',2)
grid
title('Surface velocity in x-y direction')
ylabel('velocity(m/s)')
%%
[A, Rh, ave_speed]=Flow_Measurment(SPREXY ,profile1);
Q=ave_speed*A;

end

